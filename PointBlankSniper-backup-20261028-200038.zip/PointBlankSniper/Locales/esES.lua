POINT_BLANK_SNIPER_LOCALES.esES = function()
  local L = {}
  L["FLIPPING_ENABLED"] = "TSM Flipping (se excluyen datos regionales ausentes)"
  L["FLIPPING_PERCENT"] = "% máximo de Region Sale Avg"
  L["FLIPPING_SOLD"] = "Mínimo Region Sold/Day (estrictamente superior)"
  L["FLIPPING_TSM_MISSING"] = "TSM Flipping necesita TradeSkillMaster y su API."
  L["FLIPPING_SPEND"] = "Máximo de oro por objeto (0 = sin límite)"
  L["FLIPPING_REGION_PRICE"] = "Region Sale Avg"
  L["FLIPPING_REGION_SOLD"] = "Region Sold/Day"
  L["FLIPPING_REGION_PERCENT"] = "% de Region Sale Avg"
  L["FLIPPING_PREPARED"] = "Unidades aptas: %d, total: %s"
  L["FLIPPING_ITEM_TOTAL"] = "Total: %s (%d objetos)"
  L["FLIPPING_INCOMPLETE"] = "Cargando resultados de commodities"
  L["FLIPPING_COMMODITY_UNTESTED"] = "Compra de commodities no disponible en esta versión de prueba"
  L["RAPID_BINDING"] = "Tecla de compra"
  L["RAPID_SKIP_BINDING"] = "Saltar"
  L["RAPID_KEY_CONFLICT"] = "Las teclas de compra y de saltar deben ser diferentes."
  L["RAPID_BINDING_HINT"] = "ej. CTRL-MOUSEWHEELUP; Intro guarda"
  L["RAPID_FLIPPING"] = "TSM Flipping"
  L["RAPID_FLIPPING_ON"] = "TSM: ACTIVO"
  L["RAPID_FLIPPING_OFF"] = "TSM: INACTIVO"
  L["RAPID_PERCENT"] = "% venta regional"
  L["RAPID_SOLD"] = "Vendidos/día >"
  L["RAPID_SPEND"] = "Oro máx./objeto (0 = sin límite)"
  L["RAPID_COMPLETE"] = "No hay otro resultado."
  L["RAPID_ERROR"] = "Compra fallida o no disponible; selecciona de nuevo."
  L["SKIP_RESULT"] = "Saltar resultado"
  L["DEBUG_FAKE_BUY"] = "Debug: simular compras (sin gastar oro)"
  L["DEBUG_BUY_BUTTON"] = "Simular compra"
  L["DEBUG_BUY_MESSAGE"] = "[DEBUG] COMPRA simulada: %s (ID %d)"
  L["DEBUG_SKIP_MESSAGE"] = "[DEBUG] SALTAR: %s (ID %d)"

  --@localization(locale="esES", format="lua_additive_table")@

  return L
end
